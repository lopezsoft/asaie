<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class M_sql extends SME_Model 
{	
	public function __construct() 
	{
		parent::__construct();
	}	

}


/* End of file M_sql.php */
/* Location: ./application/models/M_sql.php */
		